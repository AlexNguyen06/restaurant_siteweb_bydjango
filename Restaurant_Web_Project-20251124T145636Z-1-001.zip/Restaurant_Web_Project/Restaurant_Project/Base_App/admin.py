from django.contrib import admin
from Base_App.models import *
# Enregistrez vos modèles ici.

admin.site.register(ItemList)
admin.site.register(Items)
admin.site.register(AboutUs)
admin.site.register(Feedback)
admin.site.register(BookTable)
