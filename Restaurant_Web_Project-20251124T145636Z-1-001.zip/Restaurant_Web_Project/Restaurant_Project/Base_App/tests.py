from django.test import TestCase


from django.conf import settings
print(settings.EMAIL_HOST_PASSWORD)

